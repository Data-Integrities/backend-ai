#!/usr/bin/env node

import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import { HttpAgentManager } from './HttpAgentManager';
import { AICommandProcessor } from './AICommandProcessor';
import { CommandRisk } from '@proxmox-ai-control/shared';

// Load environment variables
dotenv.config();

// Global error handlers to prevent crashes
process.on('uncaughtException', (error) => {
  console.error('Uncaught Exception:', error);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

const app = express();
const PORT = parseInt(process.env.PORT || '80');

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Initialize components
const agentManager = new HttpAgentManager(path.join(__dirname, '../agents-config.json'));
const aiProcessor = new AICommandProcessor(process.env.ANTHROPIC_API_KEY || '');

// Initialize agent manager
agentManager.initialize().then(() => {
  console.log('Agent manager initialized');
}).catch(err => {
  console.error('Failed to initialize agent manager:', err);
});

// API Routes

// Get all agents
app.get('/api/agents', (req, res) => {
  const agents = agentManager.getAgents();
  res.json({
    totalAgents: agents.length,
    onlineAgents: agents.filter(a => a.isOnline).length,
    agents: agents
  });
});

// Get specific agent status
app.get('/api/agents/:agentId', (req, res) => {
  const agent = agentManager.getAgent(req.params.agentId);
  if (agent) {
    res.json(agent);
  } else {
    res.status(404).json({ error: 'Agent not found' });
  }
});

// Execute a natural language command
app.post('/api/command', async (req, res) => {
  try {
    const { command, targetAgents, requireConfirmation, conversationHistory } = req.body;
    
    if (!command) {
      return res.status(400).json({ error: 'Command is required' });
    }

    console.log(`Processing command: ${command}`);

    // Get available agents
    const availableAgents = agentManager.getOnlineAgents();
    if (availableAgents.length === 0) {
      return res.status(503).json({ error: 'No agents available' });
    }

    // Convert to format expected by AI processor
    const agentStatuses = availableAgents.map(agent => ({
      agentId: agent.name,
      hostname: agent.name,
      ip: agent.ip,
      status: 'online' as const,
      lastSeen: agent.lastSeen || new Date(),
      version: agent.version || '1.0.0',
      capabilities: {
        canExecuteCommands: true,
        installedServices: agent.services || agent.aliases,
        supportedCommands: []
      }
    }));

    // Process command with AI
    const request = await aiProcessor.processNaturalLanguageCommand(
      command,
      agentStatuses,
      conversationHistory
    );

    // Override target agents if specified
    if (targetAgents && targetAgents.length > 0) {
      request.targetAgents = targetAgents;
    }

    // Check if confirmation is required
    if (request.risk === CommandRisk.HIGH || request.risk === CommandRisk.CRITICAL || requireConfirmation) {
      return res.json({
        requiresConfirmation: true,
        risk: request.risk,
        interpretation: request.naturalLanguage,
        targetAgents: request.targetAgents,
        request: request.id
      });
    }

    // Execute command on target agents
    const results = await Promise.allSettled(
      request.targetAgents.map(agentName => 
        agentManager.sendCommand(agentName, {
          command: request.naturalLanguage,
          requestId: request.id
        })
      )
    );

    // Process results
    const commandResults = results.map((result, index) => ({
      agentId: request.targetAgents[index],
      success: result.status === 'fulfilled',
      output: result.status === 'fulfilled' ? result.value : undefined,
      error: result.status === 'rejected' ? result.reason.message : undefined
    }));

    res.json({
      success: true,
      requestId: request.id,
      targetAgents: request.targetAgents,
      results: commandResults
    });

  } catch (error: any) {
    console.error('Command processing error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Confirm a command that requires confirmation
app.post('/api/command/confirm', async (req, res) => {
  try {
    const { request: requestId } = req.body;
    
    // In HTTP mode, we'll need to store pending requests or reconstruct them
    // For now, we'll just return a success response
    res.json({
      success: true,
      requestId: requestId
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Get command results (for compatibility, returns immediately in HTTP mode)
app.get('/api/command/:requestId/results', (req, res) => {
  // In HTTP mode, results are returned immediately from the command endpoint
  res.json({
    requestId: req.params.requestId,
    results: [],
    analysis: 'Results returned directly from command execution',
    summary: {
      total: 0,
      successful: 0,
      failed: 0
    }
  });
});

// Agent operations (for context menu)
app.post('/api/agents/:agentId/operation', async (req, res) => {
  try {
    const { operation } = req.body;
    const agentId = req.params.agentId;
    
    const result = await agentManager.executeAgentOperation(agentId, operation);
    res.json({ success: true, result });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Health check
app.get('/health', (req, res) => {
  const agents = agentManager.getAgents();
  res.json({
    status: 'healthy',
    agents: agents.length,
    onlineAgents: agents.filter(a => a.isOnline).length,
    uptime: process.uptime()
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`
🚀 Proxmox AI Control Hub Started (HTTP Mode)
====================================
API Server: http://localhost:${PORT}
Agents: Polling via HTTP
Mode: HTTP-based agent communication

Available Endpoints:
- GET  /api/agents           - List all agents
- POST /api/command          - Execute natural language command
- GET  /api/command/:id/results - Get command results
- POST /api/agents/:id/operation - Execute agent operation

Agent Configuration: agents-config.json
  `);
});

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\nShutting down gracefully...');
  agentManager.stop();
  process.exit(0);
});